#include "ApplicationDemo.h"

RSA16 TrustedAuthority::authorityKeys(RSA16::AllInfo{ 211,137,28907,14280,737,3883 });

RSA16 ServerThread::serverKeys(RSA16::AllInfo{ 53,181,9593,2340,703,2107 });